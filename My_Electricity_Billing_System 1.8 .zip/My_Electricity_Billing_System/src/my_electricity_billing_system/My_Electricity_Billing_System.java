package my_electricity_billing_system;

public class My_Electricity_Billing_System {

    public static void main(String[] args) {
        new Login_Page().show_first_screen();
//        new Signup_Page().show_signup_screen();
//        new Admin_Page().show_admin_screen();
//        new Customer_Page().show_customer_screen();
//        new Operator_Page().show_operator_screen();

    }

}
